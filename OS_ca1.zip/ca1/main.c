#include "process.h"

// check arguements are numbers, sort for 
int main(int argc,char* argv[])
{

	// Intilaize Input String
	char input[11];
	
	//check if arguments are not null, (argc-1 it will pass enter)
	if((argc-1)!=0 && ((argc-1) %2)==0)
	{
		//auto Increment ID's, -------REFRENCE----- Storing Sruct in Array, https://stackoverflow.com/questions/10468128/how-do-you-make-an-array-of-structs-in-c				 		 
		// store struct arrray on heap, so it can be used in other functions
		process *arr_p = malloc(argc * sizeof(arr_p));
		int count = 0;
		for(int i=1;i<=argc-1;i+=2)
		{
		  
		  count++;
			arr_p[count].id = count;
			arr_p[count].at = atoi(argv[i]);
			arr_p[count].bt = atoi(argv[i+1]);
			
		}
		print_process(arr_p,argc);
		do
		{ 
						
			//Take in User input
			printf("\nPlease Enter Input \n> ");
			// to lower converts to lowercase, avoid if statements checking uppercase
			fgets(input,11,stdin);
			//replace enter at the end with '\0' for str compare
			input[(strlen(input)-1)] = '\0';

				// -------Menu System------------
				if(strcmp(input,"fifo")==0)
				{
					fifo(arr_p,argc);
				}
				else if(strcmp(input,"sjf")==0)
				{
					sjf(arr_p,argc);
				}
				else if(strcmp(input,"quit")==0)
				{
					free(arr_p);	
					printf("\nExiting Program...Good-bye\n");
				}
				else
				{
				// output error if command is not recognised
				printf("\n---ERROR---\nInvalid Command\n");
				}

			}	
			while(strcmp(input,"quit")!=0);
		}
	else
		{
			printf("\nInput Data is not correct\nNumber of Arguements passed = %d\n",argc-1);
		}
	// release memory from heap

	return 0;
}



