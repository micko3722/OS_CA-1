#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct
{
	//create a proccess, ID, Arrival Time, Burst Time
	int id;
	int at;
	int bt;
} process;


//function to print all process
void print_process(process arr_p[],int argc)
{
	printf("\nSuccessfully Added Process\n-----------------------");
	for(int i=1;i<=(argc-1)/2;++i)
	{
		printf("\nProcces P%d\n------------\nAT = %d\nBT = %d\n",arr_p[i].id,arr_p[i].at,arr_p[i].bt);
	}
	printf("\n---------------------");
}

//----------------------------------FIFO ALGORITHIM------------------------------------
void fifo(process arr_p[],int argc)
{
	//intialize for turnaround and average turnaround
	int turn=0;
	double avgturn=0;
	//intialize response time
	int resp=0;
	double avgresp=0;
	// count of array elements
	int arr_c = (argc-1)/2;
	// completion time
	int comptime=0;
	int firstturn=0;
	// Intialize Timeline
	int timeline = 0;
	printf("\n----------------------\nFIFO TIMELINE\n----------------------\n");
	for(int i=1;i<=arr_c;++i)
	{		
		timeline=arr_p[i].at;
		printf("\nT = %d  P%d\n", timeline,arr_p[i].id);
		//get the completion time
		comptime+= arr_p[i].bt;
		//get the average turn around time
		turn = (comptime - arr_p[i].at);
		//add each turn around
		avgturn += turn;
		
		//skip first element when cal Response
		if(arr_p[i].at!= 0)
		{
			// calculate all response times
			firstturn += arr_p[i-1].bt;
			resp = (firstturn - arr_p[i].at);
			avgresp +=resp;
			//printf("\nresponse time= %d-%d = %d\n  Avg = %lf\n",firstturn,arr_p[i].at,resp,avgresp);
		}
	}
	//divide to get average Turn around & Response time;
	avgturn = (avgturn/arr_c);
	avgresp = (avgresp/arr_c);
	printf("\n----------------------\nAverage Turn Around: %lf\nAverage Response Time: %lf\n",avgturn,avgresp);

};

void sjf(process arr_p[],int argc)
{

	//intialize for turnaround and average turnaround
	int turn=0;
	double avgturn=0;
	//intialize response time
	int resp=0;
	double avgresp=0;
	// count of array elements
	int arr_c = (argc-1)/2;
	// completion time
	int comptime=0;
	int firstturn=0;
	// Intialize Timeline
	int timeline = 0;

	// sort struct array by burst time, first attempt below, Reccomened bubble sort by Nichita Postalachi
	// ----------------- Refrence ---------------------- https://hackr.io/blog/bubble-sort-in-c
	
	//create array to store sorted
	//process sorted_arr[arr_c];
	//for(int i=1;i<=arr_c;++i)
	//{
		//temp = arr_p[i].bt;2
		// 
		// for(int j=1;j<=arr_c;++j)
		// {
		// 	if(arr_p[i].bt<arr_p[j].bt)
		// 	{
		// 		sorted_arr[i] = arr_p[i];
		// 	}
		// 	else if(i == (arr_c))
		// 	{
		// 		sorted_arr[arr_c] = arr_p[i];
		// 	}
		// 	else
		// 	{
		// 		sorted_arr[i] = arr_p[j];
		// 	}
		// }
		
		
	}

	print_process(sorted_arr,argc);
}